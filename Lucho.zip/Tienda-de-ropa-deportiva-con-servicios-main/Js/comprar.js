// Purchase Page JavaScript

// Global variables
let cart = [];
let subtotal = 0;
let shipping = 15.00;
let discount = 0;
let total = 0;

// DOM elements
const purchaseForm = document.getElementById('purchaseForm');
const productList = document.getElementById('productList');
const emptyCart = document.getElementById('emptyCart');
const subtotalElement = document.getElementById('subtotal');
const shippingElement = document.getElementById('shipping');
const discountElement = document.getElementById('discount');
const totalElement = document.getElementById('total');
const cartCountElement = document.getElementById('cartCount');
const creditCardDetails = document.getElementById('creditCardDetails');

// Sample cart data (in a real app, this would come from localStorage or API)
const sampleCart = [
    {
        id: 1,
        name: 'Camiseta Deportiva Nike',
        price: 45.99,
        quantity: 2,
        size: 'M',
        color: 'Azul',
        image: 'images/camiseta-nike.jpg'
    },
    {
        id: 2,
        name: 'Pantalón Adidas Running',
        price: 65.99,
        quantity: 1,
        size: 'L',
        color: 'Negro',
        image: 'images/pantalon-adidas.jpg'
    },
    {
        id: 3,
        name: 'Zapatillas Under Armour',
        price: 89.99,
        quantity: 1,
        size: '42',
        color: 'Blanco',
        image: 'images/zapatillas-ua.jpg'
    }
];

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    loadCart();
    setupEventListeners();
    setupFormValidation();
    setupPaymentMethods();
    calculateTotals();
});

// Load cart data
function loadCart() {
    // In a real app, load from localStorage or API
    cart = [...sampleCart];
    displayCart();
    updateCartCount();
}

// Display cart items
function displayCart() {
    if (cart.length === 0) {
        productList.style.display = 'none';
        emptyCart.style.display = 'block';
        return;
    }

    productList.style.display = 'block';
    emptyCart.style.display = 'none';

    productList.innerHTML = cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
            <img src="${item.image}" alt="${item.name}" class="cart-item-image" onerror="this.src='images/placeholder.jpg'">
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-details">
                    Talla: ${item.size} | Color: ${item.color}
                </div>
                <div class="cart-item-price">$${item.price.toFixed(2)}</div>
            </div>
            <div class="cart-item-quantity">
                <button type="button" class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">
                    <i class="fas fa-minus"></i>
                </button>
                <input type="number" class="quantity-input" value="${item.quantity}" min="1" 
                       onchange="setQuantity(${item.id}, this.value)">
                <button type="button" class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            <button type="button" class="remove-item" onclick="removeItem(${item.id})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
}

// Update item quantity
function updateQuantity(itemId, change) {
    const item = cart.find(item => item.id === itemId);
    if (item) {
        item.quantity = Math.max(1, item.quantity + change);
        displayCart();
        calculateTotals();
        updateCartCount();
        showNotification('Cantidad actualizada', 'success');
    }
}

// Set specific quantity
function setQuantity(itemId, quantity) {
    const item = cart.find(item => item.id === itemId);
    if (item) {
        item.quantity = Math.max(1, parseInt(quantity) || 1);
        displayCart();
        calculateTotals();
        updateCartCount();
    }
}

// Remove item from cart
function removeItem(itemId) {
    if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
        cart = cart.filter(item => item.id !== itemId);
        displayCart();
        calculateTotals();
        updateCartCount();
        showNotification('Producto eliminado del carrito', 'info');
    }
}

// Calculate totals
function calculateTotals() {
    subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Apply free shipping for orders over $100
    shipping = subtotal > 100 ? 0 : 15.00;
    
    // Apply discount for orders over $150
    discount = subtotal > 150 ? subtotal * 0.1 : 0;
    
    total = subtotal + shipping - discount;
    
    // Update display
    subtotalElement.textContent = `$${subtotal.toFixed(2)}`;
    shippingElement.textContent = shipping === 0 ? 'Gratis' : `$${shipping.toFixed(2)}`;
    discountElement.textContent = `-$${discount.toFixed(2)}`;
    totalElement.textContent = `$${total.toFixed(2)}`;
}

// Update cart count
function updateCartCount() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountElement.textContent = totalItems;
}

// Setup event listeners
function setupEventListeners() {
    // Form submission
    purchaseForm.addEventListener('submit', handleFormSubmit);
    
    // Payment method changes
    const paymentMethods = document.querySelectorAll('input[name="paymentMethod"]');
    paymentMethods.forEach(method => {
        method.addEventListener('change', handlePaymentMethodChange);
    });
    
    // Card number formatting
    const cardNumber = document.getElementById('cardNumber');
    if (cardNumber) {
        cardNumber.addEventListener('input', formatCardNumber);
    }
    
    // Card expiry formatting
    const cardExpiry = document.getElementById('cardExpiry');
    if (cardExpiry) {
        cardExpiry.addEventListener('input', formatCardExpiry);
    }
    
    // CVV validation
    const cardCvv = document.getElementById('cardCvv');
    if (cardCvv) {
        cardCvv.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '');
        });
    }
}

// Setup form validation
function setupFormValidation() {
    const inputs = purchaseForm.querySelectorAll('input[required], textarea[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', validateField);
        input.addEventListener('input', clearFieldError);
    });
}

// Setup payment methods
function setupPaymentMethods() {
    handlePaymentMethodChange(); // Initialize
}

// Handle payment method change
function handlePaymentMethodChange() {
    const selectedMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
    
    if (selectedMethod === 'credit-card') {
        creditCardDetails.style.display = 'block';
        creditCardDetails.classList.remove('hidden');
        // Make card fields required
        const cardFields = creditCardDetails.querySelectorAll('input');
        cardFields.forEach(field => field.required = true);
    } else {
        creditCardDetails.style.display = 'none';
        creditCardDetails.classList.add('hidden');
        // Remove required from card fields
        const cardFields = creditCardDetails.querySelectorAll('input');
        cardFields.forEach(field => {
            field.required = false;
            clearFieldError.call(field);
        });
    }
}

// Format card number
function formatCardNumber() {
    let value = this.value.replace(/\D/g, '');
    value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
    this.value = value;
}

// Format card expiry
function formatCardExpiry() {
    let value = this.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    this.value = value;
}

// Validate individual field
function validateField() {
    const field = this;
    const value = field.value.trim();
    const fieldName = field.name;
    let isValid = true;
    let errorMessage = '';
    
    // Clear previous error
    clearFieldError.call(field);
    
    // Required field validation
    if (field.required && !value) {
        isValid = false;
        errorMessage = 'Este campo es obligatorio';
    }
    
    // Specific field validations
    if (value && isValid) {
        switch (fieldName) {
            case 'customerEmail':
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Ingrese un email válido';
                }
                break;
                
            case 'customerPhone':
                const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
                if (!phoneRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Ingrese un teléfono válido';
                }
                break;
                
            case 'cardNumber':
                const cardRegex = /^[\d\s]{13,19}$/;
                if (!cardRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Número de tarjeta inválido';
                }
                break;
                
            case 'cardExpiry':
                const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
                if (!expiryRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Formato: MM/AA';
                }
                break;
                
            case 'cardCvv':
                const cvvRegex = /^\d{3,4}$/;
                if (!cvvRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'CVV inválido';
                }
                break;
        }
    }
    
    if (!isValid) {
        showFieldError(field, errorMessage);
    }
    
    return isValid;
}

// Show field error
function showFieldError(field, message) {
    const formGroup = field.closest('.form-group');
    const errorElement = formGroup.querySelector('.error-message');
    
    formGroup.classList.add('error');
    if (errorElement) {
        errorElement.textContent = message;
    }
}

// Clear field error
function clearFieldError() {
    const formGroup = this.closest('.form-group');
    const errorElement = formGroup.querySelector('.error-message');
    
    formGroup.classList.remove('error');
    if (errorElement) {
        errorElement.textContent = '';
    }
}

// Handle form submission
function handleFormSubmit(e) {
    e.preventDefault();
    
    // Validate all fields
    const inputs = purchaseForm.querySelectorAll('input[required], textarea[required]');
    let isFormValid = true;
    
    inputs.forEach(input => {
        if (!validateField.call(input)) {
            isFormValid = false;
        }
    });
    
    // Check if cart is not empty
    if (cart.length === 0) {
        showNotification('El carrito está vacío', 'error');
        return;
    }
    
    // Check terms acceptance
    const acceptTerms = document.getElementById('acceptTerms');
    if (!acceptTerms.checked) {
        showNotification('Debe aceptar los términos y condiciones', 'error');
        return;
    }
    
    if (isFormValid) {
        processOrder();
    } else {
        showNotification('Por favor, corrija los errores en el formulario', 'error');
        // Scroll to first error
        const firstError = purchaseForm.querySelector('.form-group.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
}

// Process order
function processOrder() {
    // Show loading state
    const submitButton = purchaseForm.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
    submitButton.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Collect form data
        const formData = new FormData(purchaseForm);
        const orderData = {
            customer: {
                name: formData.get('customerName'),
                email: formData.get('customerEmail'),
                phone: formData.get('customerPhone'),
                address: formData.get('customerAddress')
            },
            payment: {
                method: formData.get('paymentMethod'),
                cardNumber: formData.get('cardNumber'),
                cardName: formData.get('cardName'),
                cardExpiry: formData.get('cardExpiry')
            },
            products: cart,
            totals: {
                subtotal,
                shipping,
                discount,
                total
            },
            orderDate: new Date().toISOString()
        };
        
        // Log order data (in real app, send to server)
        console.log('Order processed:', orderData);
        
        // Show success message
        showOrderSuccess();
        
        // Reset form
        purchaseForm.reset();
        cart = [];
        displayCart();
        calculateTotals();
        updateCartCount();
        
        // Reset button
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
        
    }, 2000);
}

// Show order success
function showOrderSuccess() {
    const successHtml = `
        <div class="success-message show">
            <h3><i class="fas fa-check-circle"></i> ¡Pedido Procesado Exitosamente!</h3>
            <p>Su pedido ha sido recibido y será procesado en breve. Recibirá un email de confirmación.</p>
            <p><strong>Número de pedido:</strong> #${Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
        </div>
    `;
    
    purchaseForm.insertAdjacentHTML('afterbegin', successHtml);
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    // Remove success message after 10 seconds
    setTimeout(() => {
        const successMessage = document.querySelector('.success-message');
        if (successMessage) {
            successMessage.remove();
        }
    }, 10000);
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${getNotificationIcon(type)}"></i>
        <span>${message}</span>
        <button type="button" class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: 0 5px 20px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
                gap: 0.75rem;
                z-index: 1000;
                max-width: 400px;
                animation: slideInRight 0.3s ease;
            }
            .notification-success { border-left: 4px solid #27ae60; }
            .notification-error { border-left: 4px solid #e74c3c; }
            .notification-info { border-left: 4px solid #3498db; }
            .notification-close {
                background: none;
                border: none;
                cursor: pointer;
                padding: 0.25rem;
                margin-left: auto;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Close button functionality
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Get notification icon
function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'check-circle';
        case 'error': return 'exclamation-circle';
        case 'info': return 'info-circle';
        default: return 'info-circle';
    }
}

// Utility functions
function formatPrice(price) {
    return `$${price.toFixed(2)}`;
}

// Export functions for global access
window.updateQuantity = updateQuantity;
window.setQuantity = setQuantity;
window.removeItem = removeItem;