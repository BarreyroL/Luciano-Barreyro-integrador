// Main JavaScript for SportWear Application
// Global utilities and shared functionality

// Global variables
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupGlobalEventListeners();
    updateCartCount();
    setupMobileMenu();
});

// Initialize application
function initializeApp() {
    // Update cart count on page load
    updateCartCount();
    
    // Setup quantity controls if they exist
    setupQuantityControls();
    
    // Setup toggle functionality if it exists
    setupToggleFunctionality();
    
    // Setup contact form if it exists
    setupContactForm();
    
    // Setup smooth scrolling for anchor links
    setupSmoothScrolling();
}

// Setup global event listeners
function setupGlobalEventListeners() {
    // Handle navigation active states
    updateActiveNavigation();
    
    // Setup search functionality if search input exists
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        setupGlobalSearch(searchInput);
    }
}

// Setup mobile menu
function setupMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const nav = document.querySelector('.nav');
    
    if (mobileMenuBtn && nav) {
        mobileMenuBtn.addEventListener('click', () => {
            nav.classList.toggle('nav-open');
            mobileMenuBtn.classList.toggle('active');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!nav.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                nav.classList.remove('nav-open');
                mobileMenuBtn.classList.remove('active');
            }
        });
    }
}

// Setup quantity controls (for product pages)
function setupQuantityControls() {
    const quantityControls = document.querySelectorAll('.quantity-control');
    
    quantityControls.forEach(control => {
        const input = control.querySelector('.input-quantity, .quantity-input');
        const btnIncrement = control.querySelector('#increment, .quantity-btn[data-action="increment"]');
        const btnDecrement = control.querySelector('#decrement, .quantity-btn[data-action="decrement"]');
        
        if (input && btnIncrement && btnDecrement) {
            let currentValue = parseInt(input.value) || 1;
            
            btnIncrement.addEventListener('click', () => {
                currentValue += 1;
                input.value = currentValue;
                input.dispatchEvent(new Event('change'));
            });
            
            btnDecrement.addEventListener('click', () => {
                if (currentValue > 1) {
                    currentValue -= 1;
                    input.value = currentValue;
                    input.dispatchEvent(new Event('change'));
                }
            });
            
            input.addEventListener('change', () => {
                currentValue = Math.max(1, parseInt(input.value) || 1);
                input.value = currentValue;
            });
        }
    });
}

// Setup toggle functionality (for accordions, tabs, etc.)
function setupToggleFunctionality() {
    // Description toggle
    const toggleDescription = document.querySelector('.title-description');
    const contentDescription = document.querySelector('.text-description');
    
    if (toggleDescription && contentDescription) {
        toggleDescription.addEventListener('click', () => {
            contentDescription.classList.toggle('hidden');
            toggleDescription.classList.toggle('active');
        });
    }
    
    // Additional Information toggle
    const toggleAdditionalInfo = document.querySelector('.title-Additional-Information');
    const contentAdditionalInfo = document.querySelector('.text-Additional-Information');
    
    if (toggleAdditionalInfo && contentAdditionalInfo) {
        toggleAdditionalInfo.addEventListener('click', () => {
            contentAdditionalInfo.classList.toggle('hidden');
            toggleAdditionalInfo.classList.toggle('active');
        });
    }
    
    // Reviews toggle
    const toggleReviews = document.querySelector('.title-reviews');
    const contentReviews = document.querySelector('.text-reviews');
    
    if (toggleReviews && contentReviews) {
        toggleReviews.addEventListener('click', () => {
            contentReviews.classList.toggle('hidden');
            toggleReviews.classList.toggle('active');
        });
    }
    
    // Generic toggle functionality
    const toggleButtons = document.querySelectorAll('[data-toggle]');
    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-toggle');
            const target = document.getElementById(targetId);
            if (target) {
                target.classList.toggle('hidden');
                button.classList.toggle('active');
            }
        });
    });
}

// Setup contact form
function setupContactForm() {
    const contactForm = document.querySelector('#contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactFormSubmit);
    }
}

// Handle contact form submission
function handleContactFormSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = {
        name: formData.get('nombres_apellidos') || formData.get('name'),
        email: formData.get('correo') || formData.get('email'),
        phone: formData.get('celular') || formData.get('phone'),
        service: formData.get('servicio') || formData.get('service'),
        message: formData.get('mensaje') || formData.get('message')
    };
    
    // Validate form
    if (!data.name || !data.email) {
        showNotification('Por favor complete los campos obligatorios', 'error');
        return;
    }
    
    // Simulate form submission
    showNotification('Enviando mensaje...', 'info');
    
    setTimeout(() => {
        showNotification('¡Mensaje enviado exitosamente!', 'success');
        e.target.reset();
    }, 1500);
}

// Legacy function for backward compatibility
function abrirNuevaVentana() {
    const vnombre = document.getElementById("nombres_apellidos")?.value || '';
    const vcorreo = document.getElementById("correo")?.value || '';
    const vcelular = document.getElementById("celular")?.value || '';
    const vservicio = document.getElementById("servicio")?.value || '';
    
    if (!vnombre || !vcorreo) {
        showNotification('Por favor complete los campos obligatorios', 'error');
        return;
    }
    
    const url = `recibe.html?nombres_apellidos=${encodeURIComponent(vnombre)}&correo=${encodeURIComponent(vcorreo)}&celular=${encodeURIComponent(vcelular)}&servicio=${encodeURIComponent(vservicio)}`;
    
    window.open(url, "NuevaVentana", "width=750,height=600,top=150,left=187");
    
    // Clear form fields
    document.getElementById("nombres_apellidos").value = "";
    document.getElementById("correo").value = "";
    document.getElementById("celular").value = "";
    document.getElementById("servicio").value = "";
    
    showNotification('Formulario enviado', 'success');
}

// Cart Management Functions
function addToCart(product) {
    const existingItem = cart.find(item => item.id === product.id && item.size === product.size && item.color === product.color);
    
    if (existingItem) {
        existingItem.quantity += product.quantity || 1;
    } else {
        cart.push({
            ...product,
            quantity: product.quantity || 1,
            addedAt: new Date().toISOString()
        });
    }
    
    saveCart();
    updateCartCount();
    showNotification(`${product.name} agregado al carrito`, 'success');
}

function removeFromCart(productId, size, color) {
    cart = cart.filter(item => !(item.id === productId && item.size === size && item.color === color));
    saveCart();
    updateCartCount();
    showNotification('Producto eliminado del carrito', 'info');
}

function updateCartQuantity(productId, size, color, quantity) {
    const item = cart.find(item => item.id === productId && item.size === size && item.color === color);
    if (item) {
        item.quantity = Math.max(1, quantity);
        saveCart();
        updateCartCount();
    }
}

function clearCart() {
    cart = [];
    saveCart();
    updateCartCount();
    showNotification('Carrito vaciado', 'info');
}

function getCart() {
    return cart;
}

function getCartTotal() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

function getCartItemCount() {
    return cart.reduce((total, item) => total + item.quantity, 0);
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartCount() {
    const cartCountElements = document.querySelectorAll('.cart-count, #cartCount');
    const count = getCartItemCount();
    
    cartCountElements.forEach(element => {
        element.textContent = count;
        element.style.display = count > 0 ? 'block' : 'none';
    });
}

// Wishlist Management Functions
function addToWishlist(product) {
    const existingItem = wishlist.find(item => item.id === product.id);
    
    if (!existingItem) {
        wishlist.push({
            ...product,
            addedAt: new Date().toISOString()
        });
        saveWishlist();
        showNotification(`${product.name} agregado a favoritos`, 'success');
    } else {
        showNotification('El producto ya está en favoritos', 'info');
    }
}

function removeFromWishlist(productId) {
    wishlist = wishlist.filter(item => item.id !== productId);
    saveWishlist();
    showNotification('Producto eliminado de favoritos', 'info');
}

function isInWishlist(productId) {
    return wishlist.some(item => item.id === productId);
}

function getWishlist() {
    return wishlist;
}

function saveWishlist() {
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
}

// Navigation Functions
function updateActiveNavigation() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav a');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });
}

function setupSmoothScrolling() {
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                e.preventDefault();
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Search Functions
function setupGlobalSearch(searchInput) {
    let searchTimeout;
    
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            const query = e.target.value.trim();
            if (query.length >= 2) {
                performSearch(query);
            }
        }, 300);
    });
}

function performSearch(query) {
    // This would typically search through products
    // For now, we'll just show a notification
    showNotification(`Buscando: ${query}`, 'info');
}

// Notification System
function showNotification(message, type = 'info', duration = 5000) {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${getNotificationIcon(type)}"></i>
        <span>${message}</span>
        <button type="button" class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: 0 5px 20px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
                gap: 0.75rem;
                z-index: 1000;
                max-width: 400px;
                animation: slideInRight 0.3s ease;
                font-family: inherit;
            }
            .notification-success { border-left: 4px solid #27ae60; }
            .notification-error { border-left: 4px solid #e74c3c; }
            .notification-info { border-left: 4px solid #3498db; }
            .notification-warning { border-left: 4px solid #f39c12; }
            .notification-close {
                background: none;
                border: none;
                cursor: pointer;
                padding: 0.25rem;
                margin-left: auto;
                color: #666;
            }
            .notification-close:hover {
                color: #333;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOutRight {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Close button functionality
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    });
    
    // Auto remove after duration
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, duration);
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'check-circle';
        case 'error': return 'exclamation-circle';
        case 'warning': return 'exclamation-triangle';
        case 'info': return 'info-circle';
        default: return 'info-circle';
    }
}

// Utility Functions
function formatPrice(price) {
    return `$${price.toFixed(2)}`;
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Loading States
function showLoading(element) {
    element.classList.add('loading');
    element.style.pointerEvents = 'none';
}

function hideLoading(element) {
    element.classList.remove('loading');
    element.style.pointerEvents = 'auto';
}

// Export functions for global access
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.addToWishlist = addToWishlist;
window.removeFromWishlist = removeFromWishlist;
window.showNotification = showNotification;
window.formatPrice = formatPrice;
window.getCart = getCart;
window.getCartTotal = getCartTotal;
window.clearCart = clearCart;
window.abrirNuevaVentana = abrirNuevaVentana;

