// JavaScript para la página de catálogo de productos (listado_box.html)

// Datos de productos de ejemplo
const products = [
    {
        id: 1,
        name: "Camiseta Deportiva Pro",
        category: "camisetas",
        price: 45.99,
        originalPrice: 59.99,
        image: "../images/camiseta1.jpg",
        description: "Camiseta de alto rendimiento con tecnología de absorción de humedad",
        rating: 4.5,
        reviews: 128,
        sizes: ["S", "M", "L", "XL"],
        colors: ["#FF0000", "#0000FF", "#000000"],
        stock: 15,
        badge: "sale"
    },
    {
        id: 2,
        name: "Pantalón Running Elite",
        category: "pantalones",
        price: 89.99,
        originalPrice: null,
        image: "../images/pantalon1.jpg",
        description: "Pantalón ligero y transpirable para corredores profesionales",
        rating: 4.8,
        reviews: 95,
        sizes: ["S", "M", "L", "XL", "XXL"],
        colors: ["#000000", "#808080", "#000080"],
        stock: 8,
        badge: "new"
    },
    {
        id: 3,
        name: "Zapatillas Ultra Boost",
        category: "calzado",
        price: 159.99,
        originalPrice: 179.99,
        image: "../images/zapatilla1.jpg",
        description: "Zapatillas con tecnología de amortiguación avanzada",
        rating: 4.7,
        reviews: 203,
        sizes: ["38", "39", "40", "41", "42", "43", "44"],
        colors: ["#FFFFFF", "#000000", "#FF0000"],
        stock: 3,
        badge: "low-stock"
    },
    {
        id: 4,
        name: "Chaqueta Impermeable",
        category: "chaquetas",
        price: 129.99,
        originalPrice: null,
        image: "../images/chaqueta1.jpg",
        description: "Chaqueta resistente al agua con capucha ajustable",
        rating: 4.3,
        reviews: 67,
        sizes: ["S", "M", "L", "XL"],
        colors: ["#008000", "#000080", "#000000"],
        stock: 12,
        badge: "new"
    },
    {
        id: 5,
        name: "Short Training Pro",
        category: "shorts",
        price: 34.99,
        originalPrice: 44.99,
        image: "../images/short1.jpg",
        description: "Short cómodo para entrenamientos intensivos",
        rating: 4.2,
        reviews: 89,
        sizes: ["S", "M", "L", "XL"],
        colors: ["#000000", "#808080", "#000080"],
        stock: 20,
        badge: "sale"
    },
    {
        id: 6,
        name: "Top Deportivo Mujer",
        category: "tops",
        price: 39.99,
        originalPrice: null,
        image: "../images/top1.jpg",
        description: "Top de soporte medio para actividades deportivas",
        rating: 4.6,
        reviews: 156,
        sizes: ["XS", "S", "M", "L"],
        colors: ["#FF69B4", "#000000", "#FFFFFF"],
        stock: 18,
        badge: "new"
    }
];

// Variables globales
let filteredProducts = [...products];
let currentView = 'grid';
let currentPage = 1;
const productsPerPage = 6;

// Elementos del DOM
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const priceFilter = document.getElementById('priceFilter');
const sortFilter = document.getElementById('sortFilter');
const productsContainer = document.getElementById('productsContainer');
const catalogSummary = document.getElementById('catalogSummary');
const gridViewBtn = document.getElementById('gridView');
const listViewBtn = document.getElementById('listView');
const clearFiltersBtn = document.getElementById('clearFilters');

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    displayProducts();
    updateCatalogSummary();
});

// Event Listeners
function initializeEventListeners() {
    // Búsqueda
    searchInput.addEventListener('input', debounce(filterProducts, 300));
    
    // Filtros
    categoryFilter.addEventListener('change', filterProducts);
    priceFilter.addEventListener('change', filterProducts);
    sortFilter.addEventListener('change', sortProducts);
    
    // Vista
    gridViewBtn.addEventListener('click', () => setView('grid'));
    listViewBtn.addEventListener('click', () => setView('list'));
    
    // Limpiar filtros
    clearFiltersBtn.addEventListener('click', clearAllFilters);
    
    // Botón de búsqueda
    document.getElementById('searchBtn').addEventListener('click', filterProducts);
}

// Función para mostrar productos
function displayProducts() {
    if (filteredProducts.length === 0) {
        showNoResults();
        return;
    }
    
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const productsToShow = filteredProducts.slice(startIndex, endIndex);
    
    productsContainer.innerHTML = productsToShow.map(product => createProductCard(product)).join('');
    
    // Agregar event listeners a los botones de productos
    addProductEventListeners();
}

// Crear tarjeta de producto
function createProductCard(product) {
    const discountPercentage = product.originalPrice ? 
        Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;
    
    const starsHtml = generateStars(product.rating);
    const colorsHtml = product.colors.map(color => 
        `<span class="color-dot" style="background-color: ${color}" title="${color}"></span>`
    ).join('');
    
    const badgeHtml = product.badge ? 
        `<div class="product-badge ${product.badge}">
            ${product.badge === 'sale' ? `${discountPercentage}% OFF` : 
              product.badge === 'new' ? 'NUEVO' : 
              product.badge === 'low-stock' ? 'POCAS UNIDADES' : product.badge}
        </div>` : '';
    
    return `
        <div class="product-card" data-id="${product.id}">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" onerror="this.src='../images/placeholder.jpg'">
                <div class="product-overlay">
                    <button class="quick-view-btn" onclick="viewProduct(${product.id})" title="Vista rápida">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="add-to-cart-btn" onclick="addToCart(${product.id})" title="Agregar al carrito">
                        <i class="fas fa-shopping-cart"></i>
                    </button>
                </div>
                ${badgeHtml}
            </div>
            <div class="product-info">
                <div class="product-category">${product.category}</div>
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-details">
                    <div class="product-price">
                        $${product.price.toFixed(2)}
                        ${product.originalPrice ? `<span class="original-price">$${product.originalPrice.toFixed(2)}</span>` : ''}
                    </div>
                    <div class="product-rating">
                        ${starsHtml}
                        <span>(${product.reviews})</span>
                    </div>
                </div>
                <div class="product-options">
                    <div class="size-options">
                        <span>Tallas:</span> ${product.sizes.join(', ')}
                    </div>
                    <div class="color-options">
                        <span>Colores:</span>
                        <div class="color-dots">${colorsHtml}</div>
                    </div>
                </div>
                <button class="btn btn-primary btn-full" onclick="viewProduct(${product.id})">
                    Ver Producto
                </button>
            </div>
        </div>
    `;
}

// Generar estrellas de rating
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let starsHtml = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHtml += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        starsHtml += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHtml += '<i class="far fa-star"></i>';
    }
    
    return starsHtml;
}

// Agregar event listeners a productos
function addProductEventListeners() {
    // Los event listeners se agregan directamente en el HTML con onclick
    // para simplificar el código
}

// Filtrar productos
function filterProducts() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const selectedCategory = categoryFilter.value;
    const selectedPriceRange = priceFilter.value;
    
    filteredProducts = products.filter(product => {
        // Filtro de búsqueda
        const matchesSearch = searchTerm === '' || 
            product.name.toLowerCase().includes(searchTerm) ||
            product.description.toLowerCase().includes(searchTerm) ||
            product.category.toLowerCase().includes(searchTerm);
        
        // Filtro de categoría
        const matchesCategory = selectedCategory === '' || product.category === selectedCategory;
        
        // Filtro de precio
        let matchesPrice = true;
        if (selectedPriceRange) {
            const [min, max] = selectedPriceRange.split('-').map(Number);
            if (max) {
                matchesPrice = product.price >= min && product.price <= max;
            } else {
                matchesPrice = product.price >= min;
            }
        }
        
        return matchesSearch && matchesCategory && matchesPrice;
    });
    
    currentPage = 1;
    displayProducts();
    updateCatalogSummary();
}

// Ordenar productos
function sortProducts() {
    const sortBy = sortFilter.value;
    
    switch (sortBy) {
        case 'name-asc':
            filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
            break;
        case 'name-desc':
            filteredProducts.sort((a, b) => b.name.localeCompare(a.name));
            break;
        case 'price-asc':
            filteredProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-desc':
            filteredProducts.sort((a, b) => b.price - a.price);
            break;
        case 'rating-desc':
            filteredProducts.sort((a, b) => b.rating - a.rating);
            break;
        case 'newest':
            filteredProducts.sort((a, b) => b.id - a.id);
            break;
        default:
            // Orden por defecto
            break;
    }
    
    displayProducts();
}

// Cambiar vista
function setView(viewType) {
    currentView = viewType;
    
    if (viewType === 'grid') {
        productsContainer.classList.remove('list-view');
        gridViewBtn.classList.add('active');
        listViewBtn.classList.remove('active');
    } else {
        productsContainer.classList.add('list-view');
        listViewBtn.classList.add('active');
        gridViewBtn.classList.remove('active');
    }
}

// Limpiar todos los filtros
function clearAllFilters() {
    searchInput.value = '';
    categoryFilter.value = '';
    priceFilter.value = '';
    sortFilter.value = '';
    
    filteredProducts = [...products];
    currentPage = 1;
    displayProducts();
    updateCatalogSummary();
    
    showNotification('Filtros limpiados', 'info');
}

// Mostrar mensaje de no resultados
function showNoResults() {
    productsContainer.innerHTML = `
        <div class="no-results">
            <i class="fas fa-search"></i>
            <h3>No se encontraron productos</h3>
            <p>Intenta ajustar tus filtros de búsqueda</p>
            <button class="btn btn-primary" onclick="clearAllFilters()">
                Limpiar Filtros
            </button>
        </div>
    `;
}

// Actualizar resumen del catálogo
function updateCatalogSummary() {
    const totalProducts = filteredProducts.length;
    const startIndex = (currentPage - 1) * productsPerPage + 1;
    const endIndex = Math.min(currentPage * productsPerPage, totalProducts);
    
    if (catalogSummary) {
        catalogSummary.innerHTML = `
            <p>Mostrando ${startIndex}-${endIndex} de ${totalProducts} productos</p>
            <div class="pagination">
                <button class="pagination-btn" onclick="changePage(${currentPage - 1})" 
                        ${currentPage === 1 ? 'disabled' : ''}>
                    <i class="fas fa-chevron-left"></i>
                </button>
                <span class="pagination-info">Página ${currentPage} de ${Math.ceil(totalProducts / productsPerPage)}</span>
                <button class="pagination-btn" onclick="changePage(${currentPage + 1})" 
                        ${currentPage >= Math.ceil(totalProducts / productsPerPage) ? 'disabled' : ''}>
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        `;
    }
}

// Cambiar página
function changePage(newPage) {
    const totalPages = Math.ceil(filteredProducts.length / productsPerPage);
    
    if (newPage >= 1 && newPage <= totalPages) {
        currentPage = newPage;
        displayProducts();
        updateCatalogSummary();
        
        // Scroll al inicio de los productos
        productsContainer.scrollIntoView({ behavior: 'smooth' });
    }
}

// Funciones de producto
function viewProduct(productId) {
    // Redirigir a la página de producto individual
    window.location.href = `producto.html?id=${productId}`;
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        // Aquí iría la lógica para agregar al carrito
        // Por ahora solo mostramos una notificación
        showNotification(`${product.name} agregado al carrito`, 'success');
        
        // Simular actualización del contador del carrito
        updateCartCounter();
    }
}

// Mostrar notificaciones
function showNotification(message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                           type === 'error' ? 'exclamation-circle' : 
                           'info-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Agregar estilos si no existen
    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                z-index: 1000;
                animation: slideInRight 0.3s ease;
            }
            .notification-success { background: #27ae60; }
            .notification-error { background: #e74c3c; }
            .notification-info { background: #3498db; }
            .notification button {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                padding: 0;
                margin-left: 0.5rem;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Auto-remover después de 3 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}

// Actualizar contador del carrito
function updateCartCounter() {
    // Simular incremento del contador del carrito
    const cartCounter = document.querySelector('.cart-counter');
    if (cartCounter) {
        const currentCount = parseInt(cartCounter.textContent) || 0;
        cartCounter.textContent = currentCount + 1;
        cartCounter.style.display = 'block';
    }
}

// Función debounce para optimizar búsquedas
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Función para formatear precios
function formatPrice(price) {
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'EUR'
    }).format(price);
}

// Exportar funciones para uso global
window.viewProduct = viewProduct;
window.addToCart = addToCart;
window.changePage = changePage;
window.clearAllFilters = clearAllFilters;
window.setView = setView;