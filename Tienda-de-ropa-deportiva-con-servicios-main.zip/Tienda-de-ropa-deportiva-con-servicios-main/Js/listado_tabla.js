// Funcionalidad para la página de listado en tabla

// Variables globales
let allProducts = [];
let filteredProducts = [];

// Inicialización cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    initializeTable();
    setupEventListeners();
    loadProducts();
});

// Configurar event listeners
function setupEventListeners() {
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const priceFilter = document.getElementById('priceFilter');
    
    if (searchInput) {
        searchInput.addEventListener('input', filterProducts);
    }
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterProducts);
    }
    
    if (priceFilter) {
        priceFilter.addEventListener('change', filterProducts);
    }
    
    // Event listener para el botón de búsqueda
    const searchBtn = document.querySelector('.search-btn');
    if (searchBtn) {
        searchBtn.addEventListener('click', filterProducts);
    }
}

// Inicializar la tabla
function initializeTable() {
    const table = document.getElementById('productsTable');
    if (table) {
        // Obtener todas las filas de productos
        const rows = table.querySelectorAll('tbody tr');
        allProducts = Array.from(rows);
        filteredProducts = [...allProducts];
        updateProductCount();
    }
}

// Cargar productos (simulación de carga de datos)
function loadProducts() {
    // En una aplicación real, aquí cargarías los datos desde una API
    console.log('Productos cargados:', allProducts.length);
}

// Filtrar productos
function filterProducts() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const categoryFilter = document.getElementById('categoryFilter')?.value || '';
    const priceFilter = document.getElementById('priceFilter')?.value || '';
    
    filteredProducts = allProducts.filter(row => {
        const productName = row.querySelector('.product-name strong')?.textContent.toLowerCase() || '';
        const productDescription = row.querySelector('.product-name p')?.textContent.toLowerCase() || '';
        const category = row.getAttribute('data-category') || '';
        const price = parseInt(row.getAttribute('data-price')) || 0;
        
        // Filtro de búsqueda
        const matchesSearch = searchTerm === '' || 
            productName.includes(searchTerm) || 
            productDescription.includes(searchTerm);
        
        // Filtro de categoría
        const matchesCategory = categoryFilter === '' || category === categoryFilter;
        
        // Filtro de precio
        let matchesPrice = true;
        if (priceFilter !== '') {
            const [minPrice, maxPrice] = priceFilter.split('-').map(p => parseInt(p));
            matchesPrice = price >= minPrice && price <= maxPrice;
        }
        
        return matchesSearch && matchesCategory && matchesPrice;
    });
    
    displayFilteredProducts();
    updateProductCount();
}

// Mostrar productos filtrados
function displayFilteredProducts() {
    // Ocultar todas las filas
    allProducts.forEach(row => {
        row.style.display = 'none';
        row.classList.add('hidden');
    });
    
    // Mostrar solo las filas filtradas
    filteredProducts.forEach(row => {
        row.style.display = '';
        row.classList.remove('hidden');
    });
    
    // Mostrar mensaje si no hay resultados
    showNoResultsMessage(filteredProducts.length === 0);
}

// Mostrar mensaje de "no hay resultados"
function showNoResultsMessage(show) {
    let noResultsRow = document.querySelector('.no-results-row');
    
    if (show && !noResultsRow) {
        const tbody = document.querySelector('#productsTable tbody');
        noResultsRow = document.createElement('tr');
        noResultsRow.className = 'no-results-row';
        noResultsRow.innerHTML = `
            <td colspan="8" class="no-results">
                <i class="fa-solid fa-search"></i>
                <p>No se encontraron productos que coincidan con los criterios de búsqueda.</p>
                <button class="btn btn-secondary" onclick="clearFilters()">Limpiar filtros</button>
            </td>
        `;
        tbody.appendChild(noResultsRow);
    } else if (!show && noResultsRow) {
        noResultsRow.remove();
    }
}

// Limpiar filtros
function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('categoryFilter').value = '';
    document.getElementById('priceFilter').value = '';
    
    filteredProducts = [...allProducts];
    displayFilteredProducts();
    updateProductCount();
}

// Actualizar contador de productos
function updateProductCount() {
    const totalElement = document.getElementById('totalProducts');
    if (totalElement) {
        totalElement.textContent = filteredProducts.length;
    }
}

// Ver producto individual
function viewProduct(productId) {
    window.location.href = `producto.html?id=${productId}`;
}

// Agregar producto al carrito
function addToCart(productId) {
    // Obtener información del producto
    const productRow = allProducts.find(row => {
        const viewBtn = row.querySelector('button[onclick*="viewProduct(' + productId + ')"]');
        return viewBtn !== null;
    });
    
    if (productRow) {
        const productName = productRow.querySelector('.product-name strong').textContent;
        const productPrice = productRow.querySelector('.price').textContent;
        
        // Simular agregar al carrito
        showNotification(`${productName} agregado al carrito`, 'success');
        
        // En una aplicación real, aquí agregarías el producto al carrito
        console.log('Producto agregado al carrito:', {
            id: productId,
            name: productName,
            price: productPrice
        });
    }
}

// Mostrar notificación
function showNotification(message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fa-solid fa-check-circle"></i>
        <span>${message}</span>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fa-solid fa-times"></i>
        </button>
    `;
    
    // Agregar estilos si no existen
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
                display: flex;
                align-items: center;
                gap: 0.5rem;
                z-index: 1000;
                animation: slideIn 0.3s ease-out;
            }
            .notification-success {
                border-left: 4px solid #27ae60;
                color: #27ae60;
            }
            .notification-close {
                background: none;
                border: none;
                cursor: pointer;
                color: #7f8c8d;
                margin-left: 1rem;
            }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Agregar al DOM
    document.body.appendChild(notification);
    
    // Auto-remover después de 3 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}

// Ordenar tabla por columna
function sortTable(columnIndex, ascending = true) {
    const tbody = document.querySelector('#productsTable tbody');
    const rows = Array.from(tbody.querySelectorAll('tr:not(.no-results-row)'));
    
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();
        
        // Si es una columna de precio, convertir a número
        if (columnIndex === 3) { // Columna de precio
            const aPrice = parseInt(aValue.replace(/[^0-9]/g, ''));
            const bPrice = parseInt(bValue.replace(/[^0-9]/g, ''));
            return ascending ? aPrice - bPrice : bPrice - aPrice;
        }
        
        // Ordenamiento alfabético
        return ascending ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    });
    
    // Reordenar las filas en el DOM
    rows.forEach(row => tbody.appendChild(row));
}

// Exportar datos de la tabla (funcionalidad adicional)
function exportTableData() {
    const data = filteredProducts.map(row => {
        return {
            producto: row.querySelector('.product-name strong').textContent,
            categoria: row.cells[2].textContent,
            precio: row.querySelector('.price').textContent,
            tallas: row.cells[4].textContent,
            colores: row.cells[5].textContent,
            stock: row.cells[6].textContent
        };
    });
    
    console.log('Datos de productos:', data);
    // En una aplicación real, aquí podrías generar un archivo CSV o Excel
    alert('Funcionalidad de exportación disponible en consola');
}

// Funciones de utilidad
function formatPrice(price) {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0
    }).format(price);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Aplicar debounce a la búsqueda para mejor rendimiento
const debouncedFilter = debounce(filterProducts, 300);

// Reemplazar el event listener de búsqueda con la versión debounced
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.removeEventListener('input', filterProducts);
        searchInput.addEventListener('input', debouncedFilter);
    }
});