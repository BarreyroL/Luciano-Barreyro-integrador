// JavaScript para la página de producto individual

// Datos de productos (simulando una base de datos)
const productsData = {
    1: {
        id: 1,
        name: "Camiseta Deportiva Pro",
        category: "Camisetas",
        price: 45.99,
        originalPrice: 59.99,
        description: "Camiseta de alto rendimiento con tecnología de absorción de humedad. Perfecta para entrenamientos intensivos y actividades deportivas. Fabricada con materiales de primera calidad que garantizan comodidad y durabilidad.",
        rating: 4.5,
        reviews: 128,
        sizes: ["S", "M", "L", "XL"],
        colors: [
            { name: "Rojo", value: "#FF0000", code: "red" },
            { name: "Azul", value: "#0000FF", code: "blue" },
            { name: "Negro", value: "#000000", code: "black" },
            { name: "Blanco", value: "#FFFFFF", code: "white" }
        ],
        stock: 15,
        images: [
            "images/camiseta1.jpg",
            "images/camiseta2.jpg",
            "images/camiseta3.jpg",
            "images/camiseta4.jpg"
        ],
        badge: "sale",
        features: [
            "Tecnología Dri-FIT para absorción de humedad",
            "Costuras planas para mayor comodidad",
            "Ajuste atlético que permite libertad de movimiento",
            "Resistente al olor y de secado rápido",
            "Ideal para running, fitness y deportes en general"
        ],
        specifications: {
            "Material": "100% Poliéster con tecnología Dri-FIT",
            "Peso": "120g",
            "Cuidado": "Lavado a máquina en agua fría",
            "Origen": "Fabricado en Vietnam",
            "Tallas disponibles": "S, M, L, XL",
            "Colores": "Rojo, Azul, Negro, Blanco"
        }
    },
    2: {
        id: 2,
        name: "Pantalón Running Elite",
        category: "Pantalones",
        price: 89.99,
        originalPrice: null,
        description: "Pantalón ligero y transpirable para corredores profesionales. Diseñado con tecnología avanzada para máximo rendimiento.",
        rating: 4.8,
        reviews: 95,
        sizes: ["S", "M", "L", "XL", "XXL"],
        colors: [
            { name: "Negro", value: "#000000", code: "black" },
            { name: "Gris", value: "#808080", code: "gray" },
            { name: "Azul Marino", value: "#000080", code: "navy" }
        ],
        stock: 8,
        images: [
            "images/pantalon1.jpg",
            "images/pantalon2.jpg",
            "images/pantalon3.jpg"
        ],
        badge: "new"
    }
};

// Variables globales
let currentProduct = null;
let selectedSize = null;
let selectedColor = null;
let quantity = 1;
let currentImageIndex = 0;
let isZoomed = false;

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    initializeProduct();
    initializeEventListeners();
});

// Inicializar producto
function initializeProduct() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id') || '1';
    
    currentProduct = productsData[productId];
    
    if (currentProduct) {
        loadProductData();
        loadRelatedProducts();
    } else {
        showError('Producto no encontrado');
    }
}

// Cargar datos del producto
function loadProductData() {
    // Actualizar breadcrumb
    document.getElementById('productCategory').textContent = currentProduct.category;
    document.getElementById('productBreadcrumb').textContent = currentProduct.name;
    
    // Actualizar información básica
    document.getElementById('productCategoryInfo').textContent = currentProduct.category;
    document.getElementById('productTitle').textContent = currentProduct.name;
    document.getElementById('productDescription').textContent = currentProduct.description;
    
    // Actualizar precio
    document.getElementById('currentPrice').textContent = `$${currentProduct.price.toFixed(2)}`;
    
    if (currentProduct.originalPrice) {
        const originalPriceEl = document.getElementById('originalPrice');
        const discountEl = document.getElementById('discountPercentage');
        
        originalPriceEl.textContent = `$${currentProduct.originalPrice.toFixed(2)}`;
        originalPriceEl.style.display = 'inline';
        
        const discount = Math.round(((currentProduct.originalPrice - currentProduct.price) / currentProduct.originalPrice) * 100);
        discountEl.textContent = `${discount}% OFF`;
        discountEl.style.display = 'inline';
    }
    
    // Actualizar rating
    updateRating();
    
    // Actualizar badges
    updateBadges();
    
    // Actualizar galería de imágenes
    updateImageGallery();
    
    // Actualizar opciones
    updateSizeOptions();
    updateColorOptions();
    updateStock();
    
    // Actualizar tabs
    updateProductTabs();
    
    // Actualizar título de la página
    document.title = `${currentProduct.name} - SportWear Pro`;
}

// Actualizar rating
function updateRating() {
    const starsContainer = document.getElementById('productStars');
    const ratingText = document.getElementById('ratingText');
    
    starsContainer.innerHTML = generateStars(currentProduct.rating);
    ratingText.textContent = `(${currentProduct.rating} - ${currentProduct.reviews} reseñas)`;
}

// Generar estrellas
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let starsHtml = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHtml += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        starsHtml += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHtml += '<i class="far fa-star"></i>';
    }
    
    return starsHtml;
}

// Actualizar badges
function updateBadges() {
    const saleBadge = document.getElementById('saleBadge');
    const newBadge = document.getElementById('newBadge');
    const lowStockBadge = document.getElementById('lowStockBadge');
    
    // Ocultar todos los badges
    saleBadge.style.display = 'none';
    newBadge.style.display = 'none';
    lowStockBadge.style.display = 'none';
    
    // Mostrar badge apropiado
    if (currentProduct.badge === 'sale') {
        saleBadge.style.display = 'inline';
    } else if (currentProduct.badge === 'new') {
        newBadge.style.display = 'inline';
    }
    
    if (currentProduct.stock <= 5) {
        lowStockBadge.style.display = 'inline';
    }
}

// Actualizar galería de imágenes
function updateImageGallery() {
    const mainImage = document.getElementById('mainImage');
    const thumbnailGallery = document.querySelector('.thumbnail-gallery');
    
    // Actualizar imagen principal
    mainImage.src = currentProduct.images[0];
    mainImage.alt = currentProduct.name;
    
    // Actualizar thumbnails
    thumbnailGallery.innerHTML = currentProduct.images.map((image, index) => `
        <div class="thumbnail ${index === 0 ? 'active' : ''}" onclick="changeMainImage(this, ${index})">
            <img src="${image}" alt="Vista ${index + 1}" onerror="this.src='images/placeholder.jpg'">
        </div>
    `).join('');
}

// Actualizar opciones de talla
function updateSizeOptions() {
    const sizeSelector = document.querySelector('.size-selector');
    
    sizeSelector.innerHTML = currentProduct.sizes.map(size => `
        <button class="size-btn" data-size="${size}" onclick="selectSize('${size}')">
            ${size}
        </button>
    `).join('');
    
    // Seleccionar talla por defecto (M o la primera disponible)
    const defaultSize = currentProduct.sizes.includes('M') ? 'M' : currentProduct.sizes[0];
    selectSize(defaultSize);
}

// Actualizar opciones de color
function updateColorOptions() {
    const colorSelector = document.querySelector('.color-selector');
    
    colorSelector.innerHTML = currentProduct.colors.map((color, index) => {
        const borderStyle = color.code === 'white' ? 'border: 2px solid #ddd;' : '';
        return `
            <button class="color-btn ${index === 0 ? 'active' : ''}" 
                    data-color="${color.code}" 
                    style="background-color: ${color.value}; ${borderStyle}" 
                    title="${color.name}"
                    onclick="selectColor('${color.code}')">
            </button>
        `;
    }).join('');
    
    // Seleccionar primer color por defecto
    selectedColor = currentProduct.colors[0].code;
}

// Actualizar información de stock
function updateStock() {
    const stockInfo = document.getElementById('stockInfo');
    
    if (currentProduct.stock > 10) {
        stockInfo.textContent = 'En stock';
        stockInfo.style.color = '#27ae60';
    } else if (currentProduct.stock > 0) {
        stockInfo.textContent = `${currentProduct.stock} unidades disponibles`;
        stockInfo.style.color = '#f39c12';
    } else {
        stockInfo.textContent = 'Agotado';
        stockInfo.style.color = '#e74c3c';
    }
}

// Event Listeners
function initializeEventListeners() {
    // Zoom de imagen
    const mainImage = document.getElementById('mainImage');
    const imageZoom = document.getElementById('imageZoom');
    
    mainImage.addEventListener('mousemove', handleImageZoom);
    mainImage.addEventListener('mouseleave', hideImageZoom);
}

// Cambiar imagen principal
function changeMainImage(thumbnail, index = null) {
    const mainImage = document.getElementById('mainImage');
    const thumbnails = document.querySelectorAll('.thumbnail');
    
    // Remover clase active de todos los thumbnails
    thumbnails.forEach(thumb => thumb.classList.remove('active'));
    
    // Agregar clase active al thumbnail seleccionado
    thumbnail.classList.add('active');
    
    // Cambiar imagen principal
    const img = thumbnail.querySelector('img');
    mainImage.src = img.src;
    
    // Actualizar índice actual
    if (index !== null) {
        currentImageIndex = index;
    }
}

// Seleccionar talla
function selectSize(size) {
    const sizeButtons = document.querySelectorAll('.size-btn');
    
    sizeButtons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.size === size) {
            btn.classList.add('active');
        }
    });
    
    selectedSize = size;
}

// Seleccionar color
function selectColor(colorCode) {
    const colorButtons = document.querySelectorAll('.color-btn');
    
    colorButtons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.color === colorCode) {
            btn.classList.add('active');
        }
    });
    
    selectedColor = colorCode;
}

// Cambiar cantidad
function changeQuantity(delta) {
    const quantityInput = document.getElementById('quantity');
    const newQuantity = parseInt(quantityInput.value) + delta;
    
    if (newQuantity >= 1 && newQuantity <= Math.min(10, currentProduct.stock)) {
        quantity = newQuantity;
        quantityInput.value = quantity;
    }
}

// Zoom de imagen
function toggleZoom() {
    const imageZoom = document.getElementById('imageZoom');
    const mainImage = document.getElementById('mainImage');
    
    isZoomed = !isZoomed;
    
    if (isZoomed) {
        imageZoom.style.backgroundImage = `url(${mainImage.src})`;
        imageZoom.classList.add('active');
    } else {
        imageZoom.classList.remove('active');
    }
}

function handleImageZoom(e) {
    if (!isZoomed) return;
    
    const imageZoom = document.getElementById('imageZoom');
    const rect = e.target.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    imageZoom.style.backgroundPosition = `${x}% ${y}%`;
}

function hideImageZoom() {
    if (isZoomed) {
        const imageZoom = document.getElementById('imageZoom');
        imageZoom.classList.remove('active');
        isZoomed = false;
    }
}

// Mostrar tabs
function showTab(tabName) {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    // Remover clase active de todos los botones y paneles
    tabButtons.forEach(btn => btn.classList.remove('active'));
    tabPanels.forEach(panel => panel.classList.remove('active'));
    
    // Activar botón y panel seleccionado
    document.querySelector(`[onclick="showTab('${tabName}')"]`).classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

// Actualizar tabs con información del producto
function updateProductTabs() {
    // Actualizar descripción
    const descriptionTab = document.getElementById('description');
    if (currentProduct.features) {
        const featuresHtml = currentProduct.features.map(feature => `<li>${feature}</li>`).join('');
        descriptionTab.innerHTML = `
            <h3>Descripción del Producto</h3>
            <p>${currentProduct.description}</p>
            <ul>${featuresHtml}</ul>
        `;
    }
    
    // Actualizar especificaciones
    const specificationsTab = document.getElementById('specifications');
    if (currentProduct.specifications) {
        const specsHtml = Object.entries(currentProduct.specifications)
            .map(([key, value]) => `
                <tr>
                    <td><strong>${key}:</strong></td>
                    <td>${value}</td>
                </tr>
            `).join('');
        
        specificationsTab.innerHTML = `
            <h3>Especificaciones Técnicas</h3>
            <table class="specs-table">
                ${specsHtml}
            </table>
        `;
    }
    
    // Actualizar reseñas
    updateReviewsTab();
}

// Actualizar tab de reseñas
function updateReviewsTab() {
    const reviewsTab = document.getElementById('reviews');
    const starsHtml = generateStars(currentProduct.rating);
    
    reviewsTab.innerHTML = `
        <h3>Reseñas de Clientes</h3>
        <div class="reviews-summary">
            <div class="rating-breakdown">
                <div class="overall-rating">
                    <span class="rating-number">${currentProduct.rating}</span>
                    <div class="stars">${starsHtml}</div>
                    <span>Basado en ${currentProduct.reviews} reseñas</span>
                </div>
            </div>
        </div>
        
        <div class="reviews-list">
            <div class="review">
                <div class="review-header">
                    <div class="reviewer-info">
                        <strong>María González</strong>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                    </div>
                    <span class="review-date">15 de Enero, 2024</span>
                </div>
                <p>Excelente calidad y muy cómoda. La uso para correr y se mantiene seca durante todo el entrenamiento. Muy recomendada.</p>
            </div>
            
            <div class="review">
                <div class="review-header">
                    <div class="reviewer-info">
                        <strong>Carlos Ruiz</strong>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                    <span class="review-date">10 de Enero, 2024</span>
                </div>
                <p>Buena ${currentProduct.category.toLowerCase()}, aunque el ajuste es un poco más grande de lo esperado. La calidad del material es excelente.</p>
            </div>
        </div>
    `;
}

// Cargar productos relacionados
function loadRelatedProducts() {
    const relatedContainer = document.getElementById('relatedProducts');
    
    // Filtrar productos relacionados (misma categoría, excluyendo el actual)
    const relatedProducts = Object.values(productsData)
        .filter(product => product.id !== currentProduct.id && product.category === currentProduct.category)
        .slice(0, 4);
    
    if (relatedProducts.length === 0) {
        relatedContainer.innerHTML = '<p>No hay productos relacionados disponibles.</p>';
        return;
    }
    
    relatedContainer.innerHTML = relatedProducts.map(product => `
        <div class="product-card" onclick="viewProduct(${product.id})">
            <div class="product-image">
                <img src="${product.images[0]}" alt="${product.name}" onerror="this.src='images/placeholder.jpg'">
            </div>
            <div class="product-info">
                <h4>${product.name}</h4>
                <div class="product-price">
                    <span class="current-price">$${product.price.toFixed(2)}</span>
                    ${product.originalPrice ? `<span class="original-price">$${product.originalPrice.toFixed(2)}</span>` : ''}
                </div>
                <div class="product-rating">
                    ${generateStars(product.rating)}
                    <span>(${product.reviews})</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Acciones del producto
function addToCart() {
    if (!selectedSize) {
        showNotification('Por favor selecciona una talla', 'error');
        return;
    }
    
    if (!selectedColor) {
        showNotification('Por favor selecciona un color', 'error');
        return;
    }
    
    if (currentProduct.stock === 0) {
        showNotification('Producto agotado', 'error');
        return;
    }
    
    // Simular agregar al carrito
    const cartItem = {
        id: currentProduct.id,
        name: currentProduct.name,
        price: currentProduct.price,
        size: selectedSize,
        color: selectedColor,
        quantity: quantity,
        image: currentProduct.images[0]
    };
    
    // Aquí iría la lógica real del carrito
    console.log('Producto agregado al carrito:', cartItem);
    
    showNotification(`${currentProduct.name} agregado al carrito`, 'success');
    updateCartCounter();
}

function addToWishlist() {
    // Simular agregar a lista de deseos
    showNotification(`${currentProduct.name} agregado a la lista de deseos`, 'success');
    
    // Cambiar icono del botón
    const wishlistBtn = event.target.closest('.btn');
    const icon = wishlistBtn.querySelector('i');
    icon.classList.remove('far');
    icon.classList.add('fas');
    icon.style.color = '#e74c3c';
}

function buyNow() {
    if (!selectedSize || !selectedColor) {
        showNotification('Por favor selecciona talla y color', 'error');
        return;
    }
    
    // Redirigir a página de compra con parámetros
    const params = new URLSearchParams({
        id: currentProduct.id,
        size: selectedSize,
        color: selectedColor,
        quantity: quantity
    });
    
    window.location.href = `comprar.html?${params.toString()}`;
}

// Ver producto (para productos relacionados)
function viewProduct(productId) {
    window.location.href = `producto.html?id=${productId}`;
}

// Funciones de utilidad
function showNotification(message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                           type === 'error' ? 'exclamation-circle' : 
                           'info-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Agregar estilos si no existen
    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                z-index: 1000;
                animation: slideInRight 0.3s ease;
            }
            .notification-success { background: #27ae60; }
            .notification-error { background: #e74c3c; }
            .notification-info { background: #3498db; }
            .notification button {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                padding: 0;
                margin-left: 0.5rem;
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Auto-remover después de 3 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}

function updateCartCounter() {
    const cartCounter = document.getElementById('cartCounter');
    if (cartCounter) {
        const currentCount = parseInt(cartCounter.textContent) || 0;
        cartCounter.textContent = currentCount + 1;
        cartCounter.style.display = 'block';
    }
}

function showError(message) {
    document.querySelector('main').innerHTML = `
        <div style="text-align: center; padding: 4rem 2rem; color: #7f8c8d;">
            <i class="fas fa-exclamation-triangle" style="font-size: 4rem; margin-bottom: 1rem; color: #e74c3c;"></i>
            <h2 style="color: #2c3e50; margin-bottom: 1rem;">${message}</h2>
            <p style="margin-bottom: 2rem;">El producto que buscas no está disponible.</p>
            <a href="listado_box.html" class="btn btn-primary">
                <i class="fas fa-arrow-left"></i> Volver al Catálogo
            </a>
        </div>
    `;
}

// Funciones para carrito (simuladas)
function toggleCart() {
    showNotification('Funcionalidad del carrito en desarrollo', 'info');
}

function toggleSearch() {
    showNotification('Funcionalidad de búsqueda en desarrollo', 'info');
}

// Exportar funciones para uso global
window.changeMainImage = changeMainImage;
window.selectSize = selectSize;
window.selectColor = selectColor;
window.changeQuantity = changeQuantity;
window.toggleZoom = toggleZoom;
window.showTab = showTab;
window.addToCart = addToCart;
window.addToWishlist = addToWishlist;
window.buyNow = buyNow;
window.viewProduct = viewProduct;
window.toggleCart = toggleCart;
window.toggleSearch = toggleSearch;